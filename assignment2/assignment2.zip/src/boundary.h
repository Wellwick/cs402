void apply_boundary_conditions(float **u, float **v, float **p, char **flag,
    int imax, int jmax, float ui, float vi, int rank, int size);
