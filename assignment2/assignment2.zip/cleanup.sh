rm slurm*
rm karman.8*
